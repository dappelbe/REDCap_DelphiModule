# REDCap_ExternalModule_Template
Template repository to be used for REDCap Module development
